Note:

The colors in this video was slightly distorted during the videorecording. The color we used to represent ICU was red but it may appear as orange rather than red. 